<?php
include "config.php";

?>
<html>

<head>

	<link rel="stylesheet" href="css/log.css">
</head>

<body>
	<div class="left-bar">

		<div class="logBox">

			<form action="" method="post">
				<br>
				<div class="box">
					<center>
						<label>Matrix Number</label><br>
						<input autocomplete="off" type="text" name="userid" placeholder="Matrix Number" required><br>

						<label>Password</label><br>
						<input autocomplete="off" type="password" name="password" placeholder="Password" required><br>
						<?php	

if(isset($_POST["subbut"])){
	
			$user = $_POST["userid"];
			$pass = $_POST["password"];
	
		$query = 
		"SELECT * 
		FROM users 
		LEFT JOIN student ON student.studID = users.iduser 
		LEFT JOIN lecturer ON lecturer.lectID = users.iduser 
		WHERE users.iduser = '$user' 
		AND users.password= '$pass' ";
	
	$result = mysqli_query($conn,$query);
	
	if(mysqli_num_rows($result) == 1)
	{
		while ($row = mysqli_fetch_assoc($result))
		{
			$_SESSION['user'] = $row["iduser"];
			$_SESSION['role'] = $row["role"];
			$_SESSION['studName'] = $row["studName"];
			$_SESSION['lectName'] = $row["lectName"];
			$_SESSION['studDP'] = $row["studPhoto"];
			$_SESSION['lectDP'] = $row["lectPhoto"];
			
			if($row["role"] == "admin")
			{
				header('location:Admin/Admin.php');
			}
			
			else if($row["role"] == "lecturer")
			{
				header('location:Lecturer/Lecturer.php');
			}
			
			else 
			{
				header('location:Student/Student.php');
			}
			
			}
		}
	
else
{
//	header('location:index.php');
	echo "<a style=\"color:red\">Wrong Combination !</a><br>";
		
	}
}
?>
						<br><button value="submit" name="subbut" id="subbut" type="submit">Login</button>
					</center>
				</div>
			</form>

		</div>

	</div>

</body>

</html>
