
<html>

<head>

	<style>
		body {
			min-height: 1000px;

		}

		textarea, p,
		h3 {
			margin-left: 10px;
			margin-right: 10px;
			
		}
		textarea{
			width: 95%;
			resize: none;
			height: 100px;
			background-color: whitesmoke;
			color: black;
			border: none;
			white-space: pre-line;
			text-align: justify;
			padding: 5px;
	
		
		
		}

		h3 {
			text-align: justify;
			color:  #083488;
		}

		h1 {
			text-align: center;
		}
		a{
			text-decoration: none;
			margin-left: 10px;
			color: blue;
		}
		
	
	</style>
	<script>
	function autoResize() {
	console.log('resizing');
	textInput.style.height = (textInput.scrollHeight) + 'px';
}
	</script>
</head>

<body>
	<div style="background-color:dodgerblue; color:white">
		<h1>Announcement</h1><hr>
	</div>
	
	<?php
	include_once 'config.php';
//include "config.php";
	
error_reporting(E_ALL ^ E_NOTICE);
$rpp = 4;

	
isset($_GET['post']) ? $post = $_GET['post'] : $post = 0;
	
if ($post > 1){
		$start = ($post -1) * $rpp;
	}else{
		$start = 0;
	}
$viewsql = 
	"SELECT id FROM announcement";
$view = mysqli_query($conn,$viewsql);
$tot = mysqli_num_rows($view);
$totalPost = $tot / $rpp;	
	
$viewsql = 
	"SELECT title, description, post_date, bywho FROM announcement ORDER BY id DESC Limit ".$start.",".$rpp."";
	
$view = mysqli_query($conn,$viewsql);

if (! $view){
	die ('Could not get Data:'. mysqli_error($conn));
}

	
while($row = mysqli_fetch_assoc($view)){
	$title = $row['title'];
	$description = $row['description'];
	$post_date = $row['post_date'];
	$bywho = $row['bywho'];
	
	
	
	echo "<h3> {$title} </h3> ".
		"<textarea onoutput=\"autoResize(this)\" disabled>{$description}</textarea> <br>".
		"<p><b>Post By: </b>{$bywho} - {$post_date}</p>".
		"<hr>";
}
	for ($x = 1; $x <= $totalPost +1;$x++){
		echo"<a href='?post=$x'> $x </a>";
	}



?>

   
</body>

</html>
