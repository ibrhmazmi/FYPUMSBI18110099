<?php
include_once "../includes/config.php";
if (!isLecturer()) {
$_SESSION['msg'] = "You must log in first";
header('location: ../index.php');
}
if (!isLoggedIn()){
	header('location: ../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Lecturer Panel</title>
	<meta charset="UTF-8">
	<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, 
     user-scalable=0'>
	<link rel="stylesheet" href="css/lect_panel.css">
	<link rel="stylesheet" href="css/left-p.css">
	<link rel="stylesheet" href="css/right-p.css">


</head>

<body>

	<!--include header.php-->
	<?php include_once 'includes/head.php';?>
	<!--start main content-->
	<div class="main">
		<!--		left panel		-->
		<div class="left-nav">
			<a href="?view=dashboard" id="">DASHBOARD</a>
			<hr>
			<a href="?view=profile" id="">PROFILE</a>
			<hr>
			<a href="?view=student" id="">STUDENT ASSIGNED</a>
			<hr>
			<a href="?view=submission" id="">STUDENT's SUBMISSiON</a>
			<hr>

			<a href="?view=logbook" id="">STUDENT'S LOGBOOK</a>
			<?php if($_SESSION['role'] == "admin"){
			?>
			<hr>
			<a href="../Admin/Admin.php">⮂ TO ADMIN PANEL</a>
			<?php
}else{
	
}?>
			<hr>






		</div>

		<!--		left bar close-->
		<!--right bar -->
		<div class="right-bar">

			<?php 
			$view = (isset($_GET['view']) && $_GET['view'] != '') ? $_GET['view']: '';

switch ($view){
		
		//dashboard
		case 'dashboard':include_once 'dashboard.php';
		break;
		
		//profile
	case 'profile':include_once 'profile.php';
		break;
			case 'profile_edit':include_once 'profile_edit.php';
		break;
		//student
		case 'student': include_once 'student.php';
		break;
		case 'submission': include_once 'submission.php';
		break;
	
		//logbook
		case 'logbook':include_once 'logbook.php';
		break;
		case 'logbookView':include_once 'logbook_view.php';
		break;
		case 'logbookEdit':include_once 'logbook_edit.php';
		break;
		
		//marking
		case 'markingSV':include_once 'marking_SV.php';
		break;
		case 'markingEX':include_once 'marking_EX.php';
		break;
		
		//default page 
		default : include_once 'dashboard.php';
}
			?>
		</div>

	</div>
</body>

</html>
<!--
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>-->
