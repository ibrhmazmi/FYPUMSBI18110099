<?php
include_once ('../includes/config.php');
$msg = "";
error_reporting(E_ALL ^ E_NOTICE);


if(isset($_POST['addProject'])){

	$PTitle = mysqli_real_escape_string($conn,$_POST['ProjectTitle']) ;
	$id = $_SESSION['user'];
	$bywho = $_SESSION['user'];
	$stud2 = $_POST['stud2'];
	$stud3 = $_POST['stud3'];
	$sv = $_POST['sv'];
	
	$proWord = $_FILES['propWord']['name'];
	$proWordTarget = "upload/student_file/proposal/".basename($proWord);
	
	
	
	
	$sql = "
	INSERT 
	INTO project (ProjectTitle, stud1, stud2, stud3, svid, LastUpdateBy,proposalFileWord) 
	VALUES 
	('$PTitle', '$id', '$stud2', '$stud3', '$sv','$bywho','$proWord')";
	
		if (mysqli_query($conn, $sql)){
	header('location:Student.php?view=project');
}else {
	echo "Error:" . $sql . "<br>" . mysqli_error($conn);
}
	
	//	upload proposal word
	if (move_uploaded_file($_FILES['propWord']['tmp_name'], $proWordTarget)) 
	{
  		$msg = "File uploaded successfully";
  	}
	else
	{
  		$msg = "Failed to upload ";
  	}
  	
  
mysqli_close($conn);
	
	
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title> FYP Project</title>
	<link rel="stylesheet" href="css/project_add.css">

</head>

<body>
	<div class="main_form">
		<div class="plainB">
			<label>ADD FYP PROJECT</label>
			<hr>
			<div>

				<div class="box">
					<form action="" method="post" enctype="multipart/form-data">

						<table>
							<tr>
								<td id="td">TITLE</td>
								<td><textarea type="text" name="ProjectTitle" required></textarea></td>
							</tr>
							<tr>
								<td id="td">STUDENT</td>
								<td><input type="text" name="stud1" disabled value="<?php echo $_SESSION['user']; ?>"><br>

									<?php 
								//	$sql = mysqli_query($conn,"select s.studID,s.studName from student as s where not exists ( select p.Pid from project as p where s.Pid=p.Pid )") ;
								//	
								//	?>
									<input type="text" name="stud2" placeholder="STUDENT 2 (*optional)">

									<br>
									<input type="text" name="stud3" placeholder="STUDENT 3 (*optional) ">
								</td>
							</tr>
							<tr>
								<td id="td">SELECT SUPERVISOR</td>
								<td><select name="sv">
									<option value="">SELECT SUPERVISOR</option>
										<?php 
									$svcheck = mysqli_query($conn,"SELECT lectName,lectID FROM lecturer");
									
									while ($svPick = mysqli_fetch_array($svcheck)){
										echo "<option value=\"{$svPick['lectID']}\">{$svPick['lectName']}</option>";
									}
									
									?>
									</select>
								</td>
							</tr>
							<tr>
								<td>UPLOAD PROPOSAL</td>
								<td><input type='file' accept='.doc,.docx' name='propWord' required></td>
							</tr>
							<tr>
								<td></td>
								<td>
									<input type="submit" name="addProject" value="SUBMIT"><br>
									<input type="button" onclick="window.location.href='Student.php?view=project'" value="BACK">
								</td>
							</tr>
						</table>
					</form>
				</div>

			</div>

		</div>
	</div>


</body>

</html>
