<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.00, minimum-scale=1.00, maximum-scale=1.00, user-scalable=no">
</head>
<!--include header.php-->
<?php include 'includes/header.php';?>
<!--start main content-->
<div class="main">
	<!--		left bar		-->
	<?php include 'includes/left-bar.php';?>

	<!--		left bar close-->
	<!--right bar -->
	<div class="right-bar" id="display">
		<?php include 'includes/guid.php';?>

	</div>
	<!--righ bar close-->
	<!--		include footer.php-->
	<?php include 'includes/footer.php';?>
